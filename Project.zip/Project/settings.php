 <?php
session_start();

$user_id= $_SESSION['user_id'];
if(!$_SESSION['user_id'])
{
	
    header("Location: ../login.php");
}

?>

<html>
 <head>
  <title>SETTINGS</title>
   <link rel="stylesheet" type="text/css" href="style/styles.css">
 </head>
 <body>
 <div id="main">
		<nav>
			<ul>
				
				<li><a href="logout.php" >Logout</a></li>
						
				
			</ul>
		</nav>
	</div>
</body>
 
 
 <div class="setting">
		<h2>INFORMATION</h2>
		<h5><br>Firstname	&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  Middlename &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Lastname</h5>
		<h3>Username &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp 	Password &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Email</h3>
		<h4>Show Password</h4>
		<h1>Birthdate	&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Contact Number</h1>
		<b><p>Address</p></b>
		
		
		<?php

	error_reporting( ~E_NOTICE );
	
	require_once 'pdo.php';
	
	if(isset($_GET['user_id']) && !empty($_GET['user_id']))
	{
		$user_id = $_GET['user_id'];
		$stmt_edit = $DB_con->prepare('SELECT * FROM user WHERE user_id =:user_id');
		$stmt_edit->execute(array(':user_id'=>$user_id));
		$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
		extract($edit_row);
	}
	else
	{
		header("Location: index.php");
	}
	
	
	
	if(isset($_POST['btn_save_updates']))
	{
		$firstname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lastname = $_POST['lname'];
		$address = $_POST['address'];
		$email = $_POST['email'];
		$month = $_POST['month'];
		$day = $_POST['day'];
		$year = $_POST['year'];
		$contact = $_POST['contact'];
		$user = $_POST['user'];
		$pass = $_POST['pass'];

		
			
		$imgFile = $_FILES['item_images']['name'];
		$tmp_dir = $_FILES['item_images']['tmp_name'];
		$imgSize = $_FILES['item_images']['size'];
					
		if($imgFile)
		{
			$upload_dir = 'uploads/'; // upload directory	
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
			$itempic = rand(1000,1000000).".".$imgExt;
			if(in_array($imgExt, $valid_extensions))
			{			
				if($imgSize < 5000000)
				{
					unlink($upload_dir.$edit_row['item_image']);
					move_uploaded_file($tmp_dir,$upload_dir.$itempic);
				}
				else
				{
					$errMSG = "Sorry, your file is too large it should be less then 5MB";
					echo "<script>alert('Sorry, your file is too large it should be less then 5MB')</script>";				
					 
				}
			}
			else
			{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";	
              echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.')</script>";					
			}	
		}
		else
		{
		
			$itempic = $edit_row['item_images']; 
		}	
						
		

		if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare('UPDATE user
									     SET firstname=:fname,
										 mname=:mname,
										 lastname=:lname,
										 address=:address,
										 email=:email,
										 month=:month,
										 day=:day,
										 year=:year,
										 contact=:contact,
										 user=:user,
										 pass=:pass,
										     item_image=:item_images
								       WHERE user_id=:user_id');
			$stmt->bindParam(':fname',$firstname);
			$stmt->bindParam(':mname',$mname);
			$stmt->bindParam(':lname',$lastname);
			$stmt->bindParam(':address',$address);
			$stmt->bindParam(':email',$email);
			$stmt->bindParam(':month',$month);
			$stmt->bindParam(':day',$day);
			$stmt->bindParam(':year',$year);
			$stmt->bindParam(':contact',$contact);
			$stmt->bindParam(':user',$user);
			$stmt->bindParam(':pass',$pass);

			$stmt->bindParam(':item_images',$itempic);
			$stmt->bindParam(':user_id',$user_id);
				
			if($stmt->execute()){
				?>
                <script>
				alert('Successfully Updated');
				window.location.href='index.php';
				</script>
                <?php
			}
			else{
				$errMSG = "Sorry Data Could Not Updated !";
				 echo "<script>alert('Sorry Data Could Not Updated !')</script>";				
			}
		
		}
		
						
	}
	
?>

						
		

<form method="post" enctype="multipart/form-data" class="form-horizontal">
	
    
    <?php
	if(isset($errMSG)){
		?>
       
        <?php
	}
	?>
	
	
	<div class="block">
	<img src="../Project/uploads/<?php echo $item_image; ?>" class="nlogo" />
	</div>
	
	
	<input class="fname" type="text" name="fname" value="<?php echo $firstname; ?>" required />
	<input class="mname" type="text" name="mname" value="<?php echo $mname; ?>" required />
	<input class="lname" type="text" name="lname" value="<?php echo $lastname; ?>" required />
	
	<input class="user" type="text" name="user" value="<?php echo $user; ?>" required />
	<input class="pass" type="password" id="myInput" name="pass" value="<?php echo $pass; ?>" required />
	<input type="checkbox" class="check" onclick="myFunction()">
	
	<input class="email" type="text" name="email" value="<?php echo $email; ?>" required />
	
	<input class="address" type="text" name="address" value="<?php echo $address; ?>" required />
	
	<select class="month" name="month"required />
								<option name="month" style=" background: gray; "value="<?php echo $month; ?>"><?php echo $month; ?></option>
								<option name="month" value="January">January</option>
								<option name="month" value="February">February</option>
								<option name="month" value="March">March</option>
								<option name="month" value="April">April</option>
								<option name="month" value="May">May</option>
								<option name="month" value="June">June</option>
								<option name="month" value="July">July</option>
								<option name="month" value="August">August</option>
								<option name="month" value="September">September</option>
								<option name="month" value="October">October</option>
								<option name="month" value="November">November</option>
								<option name="month" value="December">December</option>
								</select>
								
	<select class="day" name="day" required />
								<option name="day" style=" background: gray; "value="<?php echo $day; ?>"><?php echo $day; ?></option>
								<option name="day" value="1">1</option>
								<option name="day" value="2">2</option>
								<option name="day" value="3">3</option>
								<option name="day" value="4">4</option>
								<option name="day" value="5">5</option>
								<option name="day" value="6">6</option>
								<option name="day" value="7">7</option>
								<option name="day" value="8">8</option>
								<option name="day" value="9">9</option>
								<option name="day" value="10">10</option>
								<option name="day" value="11">11</option>
								<option name="day" value="12">12</option>
								<option name="day" value="13">13</option>
								<option name="day" value="14">14</option>
								<option name="day" value="15">15</option>
								<option name="day" value="16">16</option>
								<option name="day" value="17">17</option>
								<option name="day" value="18">18</option>
								<option name="day" value="19">19</option>
								<option name="day" value="20">20</option>
								<option name="day" value="21">21</option>
								<option name="day" value="22">22</option>
								<option name="day" value="23">23</option>
								<option name="day" value="24">24</option>
								<option name="day" value="25">25</option>
								<option name="day" value="26">26</option>
								<option name="day" value="27">27</option>
								<option name="day" value="28">28</option>
								<option name="day" value="29">29</option>
								<option name="day" value="30">30</option>
								<option name="day" value="31">31</option>
								</select>
								
								<select class="year" name="year" required />
								<option name="year" style=" background: gray; " value="<?php echo $year; ?>"><?php echo $year; ?></option>
								<option name="year" value="2022">2022</option>
								<option name="year" value="2021">2021</option>
								<option name="year" value="2020">2020</option>
								<option name="year" value="2019">2019</option>
								<option name="year" value="2018">2018</option>
								<option name="year" value="2017">2017</option>
								<option name="year" value="2016">2016</option>
								<option name="year" value="2015">2015</option>
								<option name="year" value="2014">2014</option>
								<option name="year" value="2013">2013</option>
								<option name="year" value="2012">2012</option>
								<option name="year" value="2011">2011</option>
								<option name="year" value="2010">2010</option>
								<option name="year" value="2009">2009</option>
								<option name="year" value="2008">2008</option>
								<option name="year" value="2007">2007</option>
								<option name="year" value="2006">2006</option>
								<option name="year" value="2005">2005</option>
								<option name="year" value="2004">2004</option>
								<option name="year" value="2003">2003</option>
								<option name="year" value="2002">2002</option>
								<option name="year" value="2001">2001</option>
								<option name="year" value="2000">2000</option>
								<option name="year" value="1999">1999</option>
								<option name="year" value="1998">1998</option>
								<option name="year" value="1997">1997</option>
								<option name="year" value="1996">1996</option>
								<option name="year" value="1995">1995</option>
								<option name="year" value="1994">1994</option>
								<option name="year" value="1993">1993</option>
								<option name="year" value="1992">1992</option>
								<option name="year" value="1991">1991</option>
								<option name="year" value="1990">1990</option>
								</select>
								
								

	
	<input class="contact" type="text" name="contact" value="<?php echo $contact; ?>" required />
	
	
	<input class="file" type="file" name="item_images" accept="image/*" />
	
		
	<button type="submit" name="btn_save_updates" class="php5">Update</button>
	
	<a href="index.php" ><i class="back"> Back</i></a> 
	
	
	
 <script>
  function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>						  
    
	