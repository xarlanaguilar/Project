 <?php
session_start();

$user_username= $_SESSION['user'];
if(!$_SESSION['user'])
{
	
    header("Location: ../login.php");
}

?>


<?php

require('connection.php');

if(isset($_POST['submit']))
{
	$name = mysqli_real_escape_string($connections, $row['firstname']);
	$comment = mysqli_real_escape_string($connections, $_POST['comment']);
 
	$isql = "INSERT INTO comments (name, email, comment, status) VALUES ('$name', '$email', '$comment', 'draft')";
	$ires = mysqli_query($connections, $isql) or die(mysqli_error($connection));
	if($ires){
		$smsg = "Your Comment Submitted Successfully";
	}else{
		$fmsg = "Failed to Submit Your Comment";
	}
 
}
?>