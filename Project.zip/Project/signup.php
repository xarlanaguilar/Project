<?php
session_start();

?> 
<html>
<head>
	<title> SIGN UP</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	
             <div class="boxup">
				<caption><h2>SIGN UP</h2></caption>

	
				
				 <form enctype="multipart/form-data" method="post" action="signup.php">
                   <br><br><br><br><br>
				   
				&nbsp &nbsp &nbsp	&nbsp &nbsp  &nbsp &nbsp &nbsp Choose Image: &nbsp <input class="form-control"  type="file" name="item_image" accept="image/*" required/>
								<input class="form-control" placeholder="Firstname" name="ruser_firstname" type="text" required>
								
								<input class="form-control" placeholder="Middlename" name="ruser_middlename" type="text" >
							
						
                                <input class="form-control" placeholder="Lastname" name="ruser_lastname" type="text" required>
							
					
                                <input class="form-control" placeholder="Address" name="ruser_address" type="text" required>
								
								<select class="bday" name="ruser_date">
								<option name="ruser_date" value="Month">Month</option>
								<option name="ruser_date" value="January">January</option>
								<option name="ruser_date" value="February">February</option>
								<option name="ruser_date" value="March">March</option>
								<option name="ruser_date" value="April">April</option>
								<option name="ruser_date" value="May">May</option>
								<option name="ruser_date" value="June">June</option>
								<option name="ruser_date" value="July">July</option>
								<option name="ruser_date" value="August">August</option>
								<option name="ruser_date" value="September">September</option>
								<option name="ruser_date" value="October">October</option>
								<option name="ruser_date" value="November">November</option>
								<option name="ruser_date" value="December">December</option>
								</select>
								
								
								<select class="bdays" name="ruser_dates">
								<option name="ruser_dates" value="Day">Day</option>
								<option name="ruser_dates" value="1">1</option>
								<option name="ruser_dates" value="2">2</option>
								<option name="ruser_dates" value="3">3</option>
								<option name="ruser_dates" value="4">4</option>
								<option name="ruser_dates" value="5">5</option>
								<option name="ruser_dates" value="6">6</option>
								<option name="ruser_dates" value="7">7</option>
								<option name="ruser_dates" value="8">8</option>
								<option name="ruser_dates" value="9">9</option>
								<option name="ruser_dates" value="10">10</option>
								<option name="ruser_dates" value="11">11</option>
								<option name="ruser_dates" value="12">12</option>
								<option name="ruser_dates" value="13">13</option>
								<option name="ruser_dates" value="14">14</option>
								<option name="ruser_dates" value="15">15</option>
								<option name="ruser_dates" value="16">16</option>
								<option name="ruser_dates" value="17">17</option>
								<option name="ruser_dates" value="18">18</option>
								<option name="ruser_dates" value="19">19</option>
								<option name="ruser_dates" value="20">20</option>
								<option name="ruser_dates" value="21">21</option>
								<option name="ruser_dates" value="22">22</option>
								<option name="ruser_dates" value="23">23</option>
								<option name="ruser_dates" value="24">24</option>
								<option name="ruser_dates" value="25">25</option>
								<option name="ruser_dates" value="26">26</option>
								<option name="ruser_dates" value="27">27</option>
								<option name="ruser_dates" value="28">28</option>
								<option name="ruser_dates" value="29">29</option>
								<option name="ruser_dates" value="30">30</option>
								<option name="ruser_dates" value="31">31</option>
								</select>
								
								<select class="bdayss" name="ruser_datess">
								<option name="ruser_datess" value="Year">Year</option>
								<option name="ruser_datess" value="2022">2022</option>
								<option name="ruser_datess" value="2021">2021</option>
								<option name="ruser_datess" value="2020">2020</option>
								<option name="ruser_datess" value="2019">2019</option>
								<option name="ruser_datess" value="2018">2018</option>
								<option name="ruser_datess" value="2017">2017</option>
								<option name="ruser_datess" value="2016">2016</option>
								<option name="ruser_datess" value="2015">2015</option>
								<option name="ruser_datess" value="2014">2014</option>
								<option name="ruser_datess" value="2013">2013</option>
								<option name="ruser_datess" value="2012">2012</option>
								<option name="ruser_datess" value="2011">2011</option>
								<option name="ruser_datess" value="2010">2010</option>
								<option name="ruser_datess" value="2009">2009</option>
								<option name="ruser_datess" value="2008">2008</option>
								<option name="ruser_datess" value="2007">2007</option>
								<option name="ruser_datess" value="2006">2006</option>
								<option name="ruser_datess" value="2005">2005</option>
								<option name="ruser_datess" value="2004">2004</option>
								<option name="ruser_datess" value="2003">2003</option>
								<option name="ruser_datess" value="2002">2002</option>
								<option name="ruser_datess" value="2001">2001</option>
								<option name="ruser_datess" value="2000">2000</option>
								<option name="ruser_datess" value="1999">1999</option>
								<option name="ruser_datess" value="1998">1998</option>
								<option name="ruser_datess" value="1997">1997</option>
								<option name="ruser_datess" value="1996">1996</option>
								<option name="ruser_datess" value="1995">1995</option>
								<option name="ruser_datess" value="1994">1994</option>
								<option name="ruser_datess" value="1993">1993</option>
								<option name="ruser_datess" value="1992">1992</option>
								<option name="ruser_datess" value="1991">1991</option>
								<option name="ruser_datess" value="1990">1990</option>
								</select>
								
								
                  
															<input  placeholder="Email" name="ruser_email" type="email" required>
							
								<input class="form-control" placeholder="Number" name="ruser_number" type="text" required>
							
								<input placeholder="Username" name="ruser_username" type="text" required>
							
						
                                <input class="form-control" placeholder="Password" name="ruser_password" type="password" id="myInput" required><br>
								&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <input type="checkbox" onclick="myFunction()">&nbsp 

								<h4>Show Password</h4>
							
							

							
                  
            <br>
               
                <button class="up" name="register">Sign Up</button>
				
				
		
				   </form>
				   </div>
				  
				 
              

<?php
include("connection.php");
if(isset($_POST['register']))
{

$user_username = $_POST['ruser_username'];
$user_email = $_POST['ruser_email'];
$user_firstname = $_POST['ruser_firstname'];
$user_middlename = $_POST['ruser_middlename'];
$user_lastname = $_POST['ruser_lastname'];
$user_address = $_POST['ruser_address'];
$user_month = $_POST['ruser_date'];
$user_day = $_POST['ruser_dates'];
$user_year = $_POST['ruser_datess'];

$user_email = $_POST['ruser_email'];
$user_number = $_POST['ruser_number'];

$password = $_POST['ruser_password'];
	
$check_user="select * from user WHERE user='$user_username'";
    $run_query=mysqli_query($connections,$check_user);

    if(mysqli_num_rows($run_query)>0)
    {
echo "<script>alert('Customer is already exist, Please try another one!')</script>";
 echo"<script>window.open('signup.php','_self')</script>";
exit();
    }
 
 
$imgFile = $_FILES['item_image']['name'];
$tmp_dir = $_FILES['item_image']['tmp_name'];
$imgSize = $_FILES['item_image']['size'];

$upload_dir = 'uploads/';
$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); 
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); 
$itempic = rand(1000,1000000).".".$imgExt;


				
	
			if(in_array($imgExt, $valid_extensions)){			
		
				if($imgSize < 5000000)				{
					move_uploaded_file($tmp_dir,$upload_dir.$itempic);
					$saveitem="insert into user (user,email,pass,firstname,mname,lastname,address,month,day,year,contact,item_image) VALUE ('$user_username','$user_email','$password','$user_firstname','$user_middlename','$user_lastname','$user_address','$user_month','$user_day','$user_year','$user_number','$itempic')";
					mysqli_query($connections,$saveitem);
					 echo "<script>alert('Data successfully saved!')</script>";				
					 echo "<script>window.open('login.php','_self')</script>";
				}
				else{
					
					 echo "<script>alert('Sorry, your file is too large.')</script>";				
					 echo "<script>window.open('login.php','_self')</script>";
				}
			}
			else{
				
				 echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.')</script>";				
					 echo "<script>window.open('login.php','_self')</script>";
				
			}
		
	
		

}




?>
 <script>
  function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
