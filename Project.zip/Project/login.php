<?php
session_start(); 

?>
<html>
<head>
	<title> LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div id="main">

	</div>
	

		<div class="login">
			
		<form method=POST action=login.php>
	<h2>LOGIN</h2>
            
				
				 <form role="form" method="post" action="login.php">
                  
					
						<br><br><br><br><br>
                            
                                <input class="form-control" placeholder="Username" name="user_username" type="text" required>
							
							
							
                                <input class="form-control" placeholder="Password" name="user_password" type="password" required>
						
                 
               <br>
                <button class="btn" name="user_login">Sign In</button>
					</form>
					<br><br><br><br><br><br><br>
					<h5>-------------------------------------------------------------</h5>		
				
				<form role="form" method="post" action="signup.php">
				<button class="btns">Create new account</button>
              </div>
         
 
			
<?php

include("connection.php");

if(isset($_POST['user_login']))
{
    $user_username=$_POST['user_username'];
    $user_password=$_POST['user_password'];
	

    $check_admin="select * from user WHERE user='$user_username' AND pass='$user_password'";

 
    $run=mysqli_query($connections,$check_admin);

    if(mysqli_num_rows($run) > 0)
    {
		$row = mysqli_fetch_assoc($run);
		$user_id = $row['user_id'];
	 echo "<script>alert('You're successfully login!')</script>";
       
 echo "<script>window.open('index.php','_self')</script>";
       
$_SESSION['user']=$user_username;
$_SESSION['user_id']=$user_id;





    }
    else
    {
        echo "<script>alert('Username or password is incorrect!')</script>";
		  echo "<script>window.open('login.php','_self')</script>";
		
		 exit();
		
    }
}
?>