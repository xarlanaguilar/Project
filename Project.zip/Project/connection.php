<?php



$connections=mysqli_connect("localhost","root","");

mysqli_select_db($connections,"dbase");

?>