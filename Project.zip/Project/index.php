 <?php
session_start();

$user_id= $_SESSION['user_id'];
if(!$_SESSION['user_id'])
{
	
    header("Location: ../login.php");
}

?>

<html>
 <head>
  <title>HOME</title>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="style/styles.css">
 </head>
 <body>
 <div id="main">
		<nav>
			<ul>
				
				<li><a href="logout.php" >Logout</a></li>
						
				
			</ul>
		</nav>
	</div>
</body>
 <div class="border">
 	
 <?php
include("connection.php");

				$query = "SELECT * FROM user WHERE user_id='$user_id'";
				$result = mysqli_query($connections, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
						
					{
				?>
	<div class="img-block">
	<img src="../Project/uploads/<?php echo $row["item_image"]; ?>"  class="logo" />
	</div>
				
				<h1><?php echo $row["firstname"];?>&nbsp<?php echo $row["mname"]; ?>&nbsp<?php echo $row["lastname"]; ?>  </h1>
				<h3>@<?php echo $row["user"];?> </h3>
				<h2>📍<?php echo $row["address"];?></h2>
				<h4>🎈 Born &nbsp<?php echo $row["month"];?>&nbsp<?php echo $row["day"]; ?>,&nbsp<?php echo $row["year"]; ?> </h4>
 
 

		<a href="settings.php?user_id=<?php echo $row['user_id']; ?>" title="click for edit" onclick="return confirm('Are you sure to edit your profile?')"><span class='glyphicon glyphicon-pencil'></span>   Edit Profile</a> 
		
		
		<div class="borders">
  <div class="container">
   <form method="POST" id="comment_form">
    <div class="form-group">
     <input type="text" name="comment_name" id="comment_name" class="form-control" value="<?php echo $row["firstname"];?> <?php echo $row["lastname"]; ?>" />
    </div>
    <div class="form-group">
     <textarea name="comment_content" id="comment_content" class="form-control" placeholder="What's on your mind, <?php echo $row["firstname"];?>?" rows="5"></textarea>
    </div>
    <div class="form-group">
     <input type="hidden" name="comment_id" id="comment_id" value="0" />
     <input type="submit" name="submit" id="submit" class="btn btn-info"  value="Post" />
    </div>
   </form>
   <span id="comment_message"></span>
   <br />
   <div id="display_comment"></div>
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"add_comment.php",
   method:"POST",
   data:form_data,
   dataType:"JSON",
   success:function(data)
   {
    if(data.error != '')
    {
     $('#comment_form')[0].reset();
     $('#comment_message').html(data.error);
     $('#comment_id').val('0');
     load_comment();
    }
   }
  })
 });

 load_comment();

 function load_comment()
 {
  $.ajax({
   url:"fetch_comment.php",
   method:"POST",
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }

 $(document).on('click', '.reply', function(){
  var comment_id = $(this).attr("id");
  $('#comment_id').val(comment_id);
  $('#comment_name').focus();
 });
 
});
</script>

  <?php 
					} 
				}
				
				?>